
rootProject.name = "SysCondo"

