package entities

class SalaoDeFestas(
    val id: Int,
    val idCondominio: Condominio
)