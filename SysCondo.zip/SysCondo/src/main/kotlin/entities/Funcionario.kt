package entities

open class Funcionario (
    val id: Int,
    val idCondominio: Condominio,
    val nome: String,
    val CPF: String,
    val turno: TurnoFuncionario,
    val funcao: FuncaoFuncionario
)

enum class TurnoFuncionario {
    DIURNO,
    VESPERTINO,
    NOTURNO,
    COMPLETO
}

enum class FuncaoFuncionario {
    ZELADOR,
    PORTEIRO
}