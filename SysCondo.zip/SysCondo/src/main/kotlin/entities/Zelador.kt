package entities

class Zelador(
    id: Int,
    idCondominio: Condominio,
    nome: String,
    CPF: String,
    turno: TurnoFuncionario,
    funcao: FuncaoFuncionario

) : Funcionario(id,idCondominio, nome, CPF, turno, funcao) {
    fun registrarAchado() {

    }
}