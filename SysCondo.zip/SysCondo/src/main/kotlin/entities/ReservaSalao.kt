package entities

import java.time.LocalDateTime

data class ReservaSalao(
    val id: Int,
    val idCondominio: Condominio,
    val idCondomino: Condomino,
    val idSalaoDeFestas: SalaoDeFestas,
    val data: LocalDateTime
)