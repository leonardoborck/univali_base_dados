package entities

data class Condominio(
    val id: Int,
    val sindico: String,
    val subSindico: String,
    val nome: String,
    val CNPJ: String,
    val rua: String,
    val bairro: String,
    val numero: Int
)