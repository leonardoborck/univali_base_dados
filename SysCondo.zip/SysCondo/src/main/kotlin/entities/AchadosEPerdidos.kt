package entities

class AchadosEPerdidos(
    val id: Int,
    val idCondominio: Condominio,
    val idFuncionario: Funcionario,
    val descricao: String
)