package entities

data class Condomino(
    val id: Int,
    val nome: String,
    val CPF: String,
    val email: String,
    val senha: String,
    val celular: String,
    val telefoneFixo: String,
    val idCondominio: Condominio,
    val idSalaoDeFestas: SalaoDeFestas,
    val numeroBloco: Int,
    val numeroApartamento: Int,
)