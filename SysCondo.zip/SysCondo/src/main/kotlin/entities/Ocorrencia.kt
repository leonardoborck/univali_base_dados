package entities

data class Ocorrencia(
    val id: Int,
    val idCondominio: Condominio,
    val idCondomino: Condomino,
    val categoria: CategoriaOcorrencia,
    val descricao: String
)

enum class CategoriaOcorrencia {
    SOM_ALTO_APOS_HORARIO,
    SOM_ALTO_DURANTE_O_DIA,
    LIXO_JOGADO,
    DESRESPEITO
}