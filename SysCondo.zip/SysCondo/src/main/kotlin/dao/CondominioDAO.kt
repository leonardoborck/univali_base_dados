package dao

import connection.ConnectionFactory
import entities.Condominio
import java.sql.ResultSet

class CondominioDAO {

    fun getAllCondominios(): List<Condominio> {
        val listCondominio = mutableListOf<Condominio>()
        val query = "SELECT * FROM CONDOMINIO;"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        val resultSet: ResultSet? = statement?.executeQuery(query)
        while (resultSet?.next() == true) {
            listCondominio.add(
                Condominio(
                    resultSet.getInt("ID"),
                    resultSet.getString("NOME_SINDICO"),
                    resultSet.getString("NOME_SUB_SINDICO"),
                    resultSet.getString("NOME"),
                    resultSet.getString("CNPJ"),
                    resultSet.getString("RUA"),
                    resultSet.getString("BAIRRO"),
                    resultSet.getInt("NUMERO")
                    )
            )
        }
        return listCondominio
    }

    fun findCondominioById(id: Int): Condominio? {

        val query = "select * from condominio where id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        val resultSet: ResultSet? = statement?.executeQuery(query)
        if (resultSet != null && resultSet.next()) {
            return Condominio(
                resultSet.getInt("ID"),
                resultSet.getString("NOME_SINDICO"),
                resultSet.getString("NOME_SUB_SINDICO"),
                resultSet.getString("NOME"),
                resultSet.getString("CNPJ"),
                resultSet.getString("RUA"),
                resultSet.getString("BAIRRO"),
                resultSet.getInt("NUMERO")
            )
        }
        return null
    }

    fun insertNewCondominio(condominio: Condominio) {
        val query = "insert into condominio (nome, cnpj, rua, numero, bairro, nome_sindico, nome_sub_sindico)" +
                "VALUES('${condominio.nome}','${condominio.CNPJ}', '${condominio.rua}', ${condominio.numero}, '${condominio.bairro}', '${condominio.sindico}','${condominio.subSindico}')"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }

    fun deleteByIdCondominio(id: Int) {
        val query = "DELETE FROM condominio WHERE id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }

    fun updateByIdCondominio(coluna: String, valor: String, id: Int) {
        val query = "UPDATE condominio set $coluna = '$valor'  where id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }
}