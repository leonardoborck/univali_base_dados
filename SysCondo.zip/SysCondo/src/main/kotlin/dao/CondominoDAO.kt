package dao

import connection.ConnectionFactory
import entities.Condominio
import entities.Condomino
import entities.SalaoDeFestas
import java.sql.ResultSet
import java.sql.Statement

class CondominoDAO {

    fun getAllCondominos(): List<Condomino> {
        val listCondomino = mutableListOf<Condomino>()
        val query = "SELECT * FROM CONDOMINO;"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        val resultSet: ResultSet? = statement?.executeQuery(query)
        while (resultSet?.next() == true) {
            listCondomino.add(
                getCondomino(resultSet)
            )

        }
        return listCondomino
    }

    fun findCondominoById(id: Int): Condomino? {

        val query = "select * from condomino where id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        val resultSet: ResultSet? = statement?.executeQuery(query)
        if (resultSet != null && resultSet.next()) {
            return getCondomino(resultSet)
        }
        return null
    }

    fun insertNewCondominio(condomino: Condomino) {
        val query =
            "INSERT INTO condomino (id_condominio, id_salao_festas, nome, cpf, email, senha, celular, telefone, numero_bloco, numero_apartamento)" +
                    "VALUES (${condomino.idCondominio.id},${condomino.idSalaoDeFestas.id}, '${condomino.nome}', '${condomino.CPF}', " +
                    "'${condomino.email}', '${condomino.senha}' , '${condomino.celular}', '${condomino.telefoneFixo}', ${condomino.numeroBloco}, " +" ${condomino.numeroApartamento})"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }

    fun deleteByIdCondominio(id: Int) {
        val query = "DELETE FROM condomino WHERE id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }

    fun updateByIdCondominio(coluna: String, valor: String, id: Int) {
        val query = "UPDATE condomino set $coluna = '$valor'  where id = $id"
        println(query)
        val connection = ConnectionFactory.getConnection()
        val statement = connection?.createStatement()
        statement?.execute(query)
    }

    fun getCondomino(result: ResultSet): Condomino {

        var resultSet = result
        val statement = ConnectionFactory.getConnection()?.createStatement()

        var condominio: Condominio? = null
        var salaoDeFestas: SalaoDeFestas? = null

        val idCondominio = resultSet.getInt("ID_CONDOMINIO")
        val idSalaoDeFestas = resultSet.getInt("ID_SALAO_FESTAS")

        val idCondomino = resultSet.getInt("ID")
        val nomeCondomino = resultSet.getString("NOME")
        val cpfCondomino = resultSet.getString("CPF")
        val emailCondomino = resultSet.getString("EMAIL")
        val senhaCondomino = resultSet.getString("SENHA")

        val celularCondomino = resultSet.getString("CELULAR")
        val telefoneCondomino = resultSet.getString("TELEFONE")
        val numeroBlocoCondomino = resultSet.getInt("NUMERO_BLOCO")
        val nApartamentoCondomino = resultSet.getInt("NUMERO_APARTAMENTO")


        val queryCondominio = "select * from condominio where id = $idCondominio"
        val querySalaoDeFestas = "select * from salao_festas where id = $idSalaoDeFestas"

        resultSet = statement?.executeQuery(queryCondominio)!!
        if (resultSet.next()) {
            condominio = Condominio(
                resultSet.getInt("ID"),
                resultSet.getString("NOME_SINDICO"),
                resultSet.getString("NOME_SUB_SINDICO"),
                resultSet.getString("NOME"),
                resultSet.getString("CNPJ"),
                resultSet.getString("RUA"),
                resultSet.getString("BAIRRO"),
                resultSet.getInt("NUMERO")
            )
        }

        resultSet = statement.executeQuery(querySalaoDeFestas)
        if (resultSet != null && resultSet.next()) {
            salaoDeFestas = SalaoDeFestas(
                resultSet.getInt("ID"),
                condominio!!
            )
        }

        return Condomino(
            idCondomino,
            nomeCondomino,
            cpfCondomino,
            emailCondomino,
            senhaCondomino,
            celularCondomino,
            telefoneCondomino,
            condominio!!,
            salaoDeFestas!!,
            numeroBlocoCondomino,
            nApartamentoCondomino
        )
    }
}