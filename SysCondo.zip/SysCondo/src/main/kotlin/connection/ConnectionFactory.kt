package connection

import org.postgresql.util.PSQLException
import java.sql.*
import java.util.*

class ConnectionFactory {

    companion object{
        private const val username = "postgres"
        private const val password = "root"
        private var connection: Connection? = null

        fun getConnection() : Connection? {
            val connectionProps = Properties()
            connectionProps["user"] = username
            connectionProps["password"] = password
            try {
                Class.forName("org.postgresql.Driver").newInstance()
                connection = DriverManager.getConnection(
                    "jdbc:" + "postgresql" + "://" + "127.0.0.1" + ":" + "5432" + "/", connectionProps
                )
                return connection
            } catch (ex: SQLException) {
                ex.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return null
        }

        fun closeConnection(){
            connection?.close();
        }
    }





}