import connection.ConnectionFactory
import dao.CondominioDAO
import dao.CondominoDAO
import entities.Condominio
import entities.Condomino
import entities.SalaoDeFestas

fun main(args: Array<String>) {

//    val dao = CondominioDAO()
//    dao.getAllCondominios().forEach { println(it) }
//        println(dao.findCondominioById(1))
//    dao.insertNewCondominio();
//    dao.deleteByIdCondominio(3)

    val dao = CondominoDAO()
    var condominio =
        Condominio(2, "Joao", "Jakson", "Condominio Doce Lar", "284.875.857/4545-54", "Rua da Alegria", "Areias", 15)
    dao.getAllCondominos().forEach { println(it) }
//    println(dao.findCondominoById(1))
//    dao.insertNewCondominio(Condomino(1,"Joao","181.456.789-88","joao@gmail.com","1544","78874545","45455454",
//        condominio,
//        SalaoDeFestas(1,condominio),15,111
//        )
//    )
//    dao.deleteByIdCondominio(3)
}